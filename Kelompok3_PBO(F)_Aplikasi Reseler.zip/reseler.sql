-- phpMyAdmin SQL Dump
-- version 5.2.1-dev+20220604.be7357420b
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2022 at 04:57 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reseler`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id_akun` int(11) NOT NULL,
  `nama_akun` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `no_hp` int(50) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id_akun`, `nama_akun`, `email`, `password`, `no_hp`, `alamat`) VALUES
(2, 'Arvito Caesario Arifianto Putra', '202410103064@mail.unej.ac.id', 'papbof3', 812345678, 'Banyuwangi'),
(3, 'Muhammad Rosyid Iqbal Haqiqi', '202410103025@mail.unej.ac.id', 'papbof3', 813579246, 'Jember'),
(4, 'Gita Nanda Wilujeng 	', '202410103003@mail.unej.ac.id', 'papbof3', 851285492, 'Jember'),
(5, 'Salsa Zannuba Arifah Khabsoh ', '202410103037@mail.unej.ac.id', 'papbof3', 872484329, 'Jember');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `stok_barang` int(50) NOT NULL,
  `harga_barang` int(50) NOT NULL,
  `jenis_barang` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `stok_barang`, `harga_barang`, `jenis_barang`) VALUES
(1, 'Indomie', 50, 2500, 'Mie instan'),
(2, 'Sonice', 20, 1000, 'Sosis'),
(3, 'Mie sedap', 10, 2600, 'Mie instan'),
(4, 'Kimbo', 30, 1000, 'Sosis'),
(5, 'Nabati', 40, 3000, 'Wafer'),
(11, 'Bimoli', 50, 21000, 'Minyak goreng'),
(12, 'Sania', 50, 20000, 'Minyak goreng'),
(13, 'Fortune', 50, 19000, 'Minyak goreng'),
(14, 'ABC 100ml', 20, 8000, 'Saos sambal'),
(15, 'Indofood 100ml', 20, 7800, 'Saos sambal'),
(16, 'Silver Queen', 100, 25000, 'Coklat');

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

CREATE TABLE `laporan` (
  `id_laporan` int(11) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`id_laporan`, `deskripsi`) VALUES
(1, 'Laporan 11 Juni 2022');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `pemasukan` int(100) NOT NULL,
  `pengeluaran` int(100) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `jumlah_barang_masuk` int(100) NOT NULL,
  `jumlah_barang_keluar` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `pemasukan`, `pengeluaran`, `metode_pembayaran`, `jumlah_barang_masuk`, `jumlah_barang_keluar`) VALUES
(4, '11 June 2022', 50000, 20000, 'Debit', 50, 20),
(5, '11 June 2022', 500000, 200000, 'Debit', 25, 20),
(6, '12 June 2022', 250000, 50000, 'Cash', 50, 100),
(9, '14 June 2022', 500000, 100000, 'Cash', 50, 200),
(10, '16 June 2022', 800000, 175000, 'Cash', 100, 45);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`id_laporan`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `laporan`
--
ALTER TABLE `laporan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
