﻿using FizzWare.NBuilder.Dates;
using ProjectPBO.fiturPencatatan.viewPencatatan;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO
{
    public partial class Beranda : Form
    {
        public Beranda()
        {
            InitializeComponent();
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            // Masuk Pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Masuk Laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_stok_Click_1(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_pencatatan_Click(object sender, EventArgs e)
        {
            // Masuk Pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_laporan_Click(object sender, EventArgs e)
        {
            // Masuk Laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_dashboard_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_stk_Click(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt_Click(object sender, EventArgs e)
        {
            // Masuk Pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr_Click(object sender, EventArgs e)
        {
            // Masuk Laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_prf_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void tbl_profil_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void Beranda_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }

    }
}
