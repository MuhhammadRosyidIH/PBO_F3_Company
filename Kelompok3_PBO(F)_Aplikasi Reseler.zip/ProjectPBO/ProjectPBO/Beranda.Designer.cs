﻿namespace ProjectPBO
{
    partial class Beranda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tbl_prf = new System.Windows.Forms.Label();
            this.tbl_lpr = new System.Windows.Forms.Label();
            this.tbl_ctt = new System.Windows.Forms.Label();
            this.tbl_stk = new System.Windows.Forms.Label();
            this.tbl_dashboard = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tbl_pencatatan = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tbl_stok = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tbl_laporan = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tbl_profil = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.jam = new System.Windows.Forms.Label();
            this.tanggalHariIni = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Coral;
            this.groupBox5.Controls.Add(this.pictureBox10);
            this.groupBox5.Controls.Add(this.pictureBox9);
            this.groupBox5.Controls.Add(this.pictureBox8);
            this.groupBox5.Controls.Add(this.pictureBox7);
            this.groupBox5.Controls.Add(this.pictureBox6);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.tbl_prf);
            this.groupBox5.Controls.Add(this.tbl_lpr);
            this.groupBox5.Controls.Add(this.tbl_ctt);
            this.groupBox5.Controls.Add(this.tbl_stk);
            this.groupBox5.Controls.Add(this.tbl_dashboard);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.groupBox4);
            this.groupBox5.Location = new System.Drawing.Point(0, 69);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 674);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox10.Location = new System.Drawing.Point(63, 495);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 12;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox9.Location = new System.Drawing.Point(61, 442);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 12;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox8.Location = new System.Drawing.Point(61, 392);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 12;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox7.Location = new System.Drawing.Point(61, 347);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox6.Location = new System.Drawing.Point(61, 299);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox6.Location = new System.Drawing.Point(6, 291);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(10, 33);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            // 
            // tbl_prf
            // 
            this.tbl_prf.AutoSize = true;
            this.tbl_prf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf.ForeColor = System.Drawing.Color.White;
            this.tbl_prf.Location = new System.Drawing.Point(89, 349);
            this.tbl_prf.Name = "tbl_prf";
            this.tbl_prf.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf.TabIndex = 9;
            this.tbl_prf.Text = "Profil";
            this.tbl_prf.Click += new System.EventHandler(this.tbl_prf_Click);
            // 
            // tbl_lpr
            // 
            this.tbl_lpr.AutoSize = true;
            this.tbl_lpr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr.Location = new System.Drawing.Point(91, 497);
            this.tbl_lpr.Name = "tbl_lpr";
            this.tbl_lpr.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr.TabIndex = 8;
            this.tbl_lpr.Text = "Laporan";
            this.tbl_lpr.Click += new System.EventHandler(this.tbl_lpr_Click);
            // 
            // tbl_ctt
            // 
            this.tbl_ctt.AutoSize = true;
            this.tbl_ctt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt.Location = new System.Drawing.Point(91, 444);
            this.tbl_ctt.Name = "tbl_ctt";
            this.tbl_ctt.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt.TabIndex = 7;
            this.tbl_ctt.Text = "Pencatatan";
            this.tbl_ctt.Click += new System.EventHandler(this.tbl_ctt_Click);
            // 
            // tbl_stk
            // 
            this.tbl_stk.AutoSize = true;
            this.tbl_stk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stk.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stk.ForeColor = System.Drawing.Color.White;
            this.tbl_stk.Location = new System.Drawing.Point(89, 394);
            this.tbl_stk.Name = "tbl_stk";
            this.tbl_stk.Size = new System.Drawing.Size(103, 23);
            this.tbl_stk.TabIndex = 6;
            this.tbl_stk.Text = "Stok Barang";
            this.tbl_stk.Click += new System.EventHandler(this.tbl_stk_Click);
            // 
            // tbl_dashboard
            // 
            this.tbl_dashboard.AutoSize = true;
            this.tbl_dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard.Location = new System.Drawing.Point(89, 301);
            this.tbl_dashboard.Name = "tbl_dashboard";
            this.tbl_dashboard.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard.TabIndex = 5;
            this.tbl_dashboard.Text = "Dashboard";
            this.tbl_dashboard.Click += new System.EventHandler(this.tbl_dashboard_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectPBO.Properties.Resources.r_letter_company_logo_9A44363CA1_seeklogo_com;
            this.pictureBox1.Location = new System.Drawing.Point(61, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Bisque;
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Location = new System.Drawing.Point(0, 223);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(266, 57);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(89, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "MENU";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox1.Controls.Add(this.groupBox11);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox10);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(0, -1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1268, 686);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Bisque;
            this.groupBox11.Controls.Add(this.tbl_pencatatan);
            this.groupBox11.Controls.Add(this.pictureBox5);
            this.groupBox11.Location = new System.Drawing.Point(791, 251);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(200, 200);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            // 
            // tbl_pencatatan
            // 
            this.tbl_pencatatan.BackColor = System.Drawing.Color.SkyBlue;
            this.tbl_pencatatan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_pencatatan.ForeColor = System.Drawing.Color.White;
            this.tbl_pencatatan.Location = new System.Drawing.Point(37, 152);
            this.tbl_pencatatan.Name = "tbl_pencatatan";
            this.tbl_pencatatan.Size = new System.Drawing.Size(133, 28);
            this.tbl_pencatatan.TabIndex = 14;
            this.tbl_pencatatan.Text = "Lihat";
            this.tbl_pencatatan.UseVisualStyleBackColor = false;
            this.tbl_pencatatan.Click += new System.EventHandler(this.tbl_pencatatan_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox5.Location = new System.Drawing.Point(55, 19);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(90, 90);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Bisque;
            this.groupBox8.Controls.Add(this.tbl_stok);
            this.groupBox8.Controls.Add(this.pictureBox3);
            this.groupBox8.Location = new System.Drawing.Point(538, 251);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 200);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            // 
            // tbl_stok
            // 
            this.tbl_stok.BackColor = System.Drawing.Color.SkyBlue;
            this.tbl_stok.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stok.ForeColor = System.Drawing.Color.White;
            this.tbl_stok.Location = new System.Drawing.Point(37, 152);
            this.tbl_stok.Name = "tbl_stok";
            this.tbl_stok.Size = new System.Drawing.Size(133, 28);
            this.tbl_stok.TabIndex = 12;
            this.tbl_stok.Text = "Lihat";
            this.tbl_stok.UseVisualStyleBackColor = false;
            this.tbl_stok.Click += new System.EventHandler(this.tbl_stok_Click_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox3.Location = new System.Drawing.Point(55, 19);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(90, 90);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.Bisque;
            this.groupBox10.Controls.Add(this.tbl_laporan);
            this.groupBox10.Controls.Add(this.pictureBox4);
            this.groupBox10.Location = new System.Drawing.Point(1037, 251);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(200, 200);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            // 
            // tbl_laporan
            // 
            this.tbl_laporan.BackColor = System.Drawing.Color.SkyBlue;
            this.tbl_laporan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_laporan.ForeColor = System.Drawing.Color.White;
            this.tbl_laporan.Location = new System.Drawing.Point(37, 152);
            this.tbl_laporan.Name = "tbl_laporan";
            this.tbl_laporan.Size = new System.Drawing.Size(133, 28);
            this.tbl_laporan.TabIndex = 13;
            this.tbl_laporan.Text = "Lihat";
            this.tbl_laporan.UseVisualStyleBackColor = false;
            this.tbl_laporan.Click += new System.EventHandler(this.tbl_laporan_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox4.Location = new System.Drawing.Point(55, 19);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(90, 90);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Bisque;
            this.groupBox7.Controls.Add(this.tbl_profil);
            this.groupBox7.Controls.Add(this.pictureBox2);
            this.groupBox7.Location = new System.Drawing.Point(290, 251);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 200);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            // 
            // tbl_profil
            // 
            this.tbl_profil.BackColor = System.Drawing.Color.SkyBlue;
            this.tbl_profil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_profil.ForeColor = System.Drawing.Color.White;
            this.tbl_profil.Location = new System.Drawing.Point(37, 152);
            this.tbl_profil.Name = "tbl_profil";
            this.tbl_profil.Size = new System.Drawing.Size(133, 28);
            this.tbl_profil.TabIndex = 11;
            this.tbl_profil.Text = "Lihat";
            this.tbl_profil.UseVisualStyleBackColor = false;
            this.tbl_profil.Click += new System.EventHandler(this.tbl_profil_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox2.Location = new System.Drawing.Point(55, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 90);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Location = new System.Drawing.Point(261, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1005, 30);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(11, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(199, 23);
            this.label10.TabIndex = 3;
            this.label10.Text = "WELCOME, Kelompok F3";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox2.Controls.Add(this.jam);
            this.groupBox2.Controls.Add(this.tanggalHariIni);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1268, 70);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // jam
            // 
            this.jam.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jam.ForeColor = System.Drawing.Color.White;
            this.jam.Location = new System.Drawing.Point(1112, 13);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(149, 21);
            this.jam.TabIndex = 7;
            this.jam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tanggalHariIni
            // 
            this.tanggalHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggalHariIni.ForeColor = System.Drawing.Color.White;
            this.tanggalHariIni.Location = new System.Drawing.Point(1147, 41);
            this.tanggalHariIni.Name = "tanggalHariIni";
            this.tanggalHariIni.Size = new System.Drawing.Size(115, 22);
            this.tanggalHariIni.TabIndex = 6;
            this.tanggalHariIni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 31);
            this.label4.TabIndex = 5;
            this.label4.Text = "Aplikasi Reseler";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nama Aplikasi";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Beranda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Name = "Beranda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Beranda";
            this.Load += new System.EventHandler(this.Beranda_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label tbl_prf;
        private System.Windows.Forms.Label tbl_lpr;
        private System.Windows.Forms.Label tbl_ctt;
        private System.Windows.Forms.Label tbl_stk;
        private System.Windows.Forms.Label tbl_dashboard;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button tbl_pencatatan;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button tbl_stok;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button tbl_laporan;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button tbl_profil;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label tanggalHariIni;
        private System.Windows.Forms.Timer timer1;
    }
}