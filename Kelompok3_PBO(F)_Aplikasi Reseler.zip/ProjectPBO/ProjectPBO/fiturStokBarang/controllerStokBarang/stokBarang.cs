﻿using ProjectPBO.modelStokBarang;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO.controllerStokBarang
{
    class stokBarang
    {
        //Memanggil class koneksi dan membuat objekk baru
        koneksi Koneksi = new koneksi();

        //Method insert
        public bool Insert(modelStok stok)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("INSERT INTO barang (nama_barang, stok_barang, harga_barang, jenis_barang) VALUES ('" + stok.Nama_barang + "', '" + stok.Stok_barang + "', '" + stok.Harga_barang + "', '" + stok.Jenis_barang + "')");
                status = true;
                MessageBox.Show("Data stok barang berhasil ditambahkan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }

        public bool Update(modelStok stok, string id_brg)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("UPDATE barang SET nama_barang='" + stok.Nama_barang + "', "+"stok_barang='" + stok.Stok_barang + "', "+"harga_barang='" + stok.Harga_barang + "', " + "jenis_barang='" + stok.Jenis_barang + "' WHERE id_barang='" + id_brg +"'");
                status = true;
                MessageBox.Show("Data stok barang berhasil diubah", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }

        public bool Delete(string id_brg)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("DELETE FROM barang WHERE id_barang='" + id_brg +"'");
                status = true;
                MessageBox.Show("Data stok barang berhasil diubah", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }
    }
}
