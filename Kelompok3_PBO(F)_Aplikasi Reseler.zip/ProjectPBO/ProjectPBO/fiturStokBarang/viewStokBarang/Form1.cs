﻿using ProjectPBO.controllerStokBarang;
using ProjectPBO.fiturPencatatan.viewPencatatan;
using ProjectPBO.modelStokBarang;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO
{
    public partial class Form1 : Form
    {
        // Panggil class koneksi dan modelCatatan untuk menghubungkan ke database dan sistem
        // yang ada pada fitur pencatatan
        koneksi Koneksi = new koneksi();
        modelStok stok = new modelStok();
        string id_brg;

        public void Tampil()
        {
            // Query database
            tabel_stok.DataSource = Koneksi.ShowData("SELECT * FROM barang");
            //Mengubah nama kolom
            tabel_stok.Columns[0].HeaderText = "NO";
            tabel_stok.Columns[1].HeaderText = "NAMA BARANG";
            tabel_stok.Columns[2].HeaderText = "STOK";
            tabel_stok.Columns[3].HeaderText = "HARGA";
            tabel_stok.Columns[4].HeaderText = "JENIS BARANG";
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // panggil method tampil
            Tampil();
            timer1.Start();
        }

        private void tombol_simpan_Click(object sender, EventArgs e)
        {
            // Cek seluruh value yang ada pada textbox, jika kosong akan 
            // menampilkan message seperti dibawah
            if (nama_barang.Text == "" || jumlah_barang.Text == "" || harga_barang.Text == "" || jenis_barang.Text == "")
            {
                MessageBox.Show("Harap isi dulu!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else 
            {
                // Jika telah terisi value kita dapat memasukkannya ke dalam sistem class Catatan 
                // kemudian diteruskan ke database dengan menggunakan query insert pada class tersebut
                stokBarang stk = new stokBarang();
                stok.Nama_barang = nama_barang.Text;
                stok.Stok_barang = jumlah_barang.Text;
                stok.Harga_barang = harga_barang.Text;
                stok.Jenis_barang = jenis_barang.Text;

                stk.Insert(stok);
                nama_barang.Text = "";
                jumlah_barang.Text = "";
                harga_barang.Text = "";
                jenis_barang.Text = "";
                // Method untuk menampilkan data yang telah terhapus ke dalam layar
                Tampil();
            }
        }

        private void tabel_stok_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Untuk memilih data yang ingin dihapus berdasarkan id nya
            id_brg = tabel_stok.Rows[e.RowIndex].Cells[0].Value.ToString();
            nama_barang.Text = tabel_stok.Rows[e.RowIndex].Cells[1].Value.ToString();
            jumlah_barang.Text = tabel_stok.Rows[e.RowIndex].Cells[2].Value.ToString();
            harga_barang.Text = tabel_stok.Rows[e.RowIndex].Cells[3].Value.ToString();
            jenis_barang.Text = tabel_stok.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void tombol_ubah_Click(object sender, EventArgs e)
        {
            // Cek seluruh value yang ada pada textbox, jika kosong akan 
            // menampilkan message seperti dibawah
            if (nama_barang.Text == "" || jumlah_barang.Text == "" || harga_barang.Text == "" || jenis_barang.Text == "")
            {
                MessageBox.Show("Harap isi dulu!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // Jika telah terisi value kita dapat memasukkannya ke dalam sistem class Catatan 
                // kemudian diteruskan ke database dengan menggunakan query update pada class tersebut
                stokBarang stk = new stokBarang();
                stok.Nama_barang = nama_barang.Text;
                stok.Stok_barang = jumlah_barang.Text;
                stok.Harga_barang = harga_barang.Text;
                stok.Jenis_barang = jenis_barang.Text;

                stk.Update(stok,id_brg);
                nama_barang.Text = "";
                jumlah_barang.Text = "";
                harga_barang.Text = "";
                jenis_barang.Text = "";
                // Method untuk menampilkan data yang telah terhapus ke dalam layar
                Tampil();
            }
        }

        private void tombol_hapus_Click(object sender, EventArgs e)
        {
            // Untuk menghapus data sesuai id nya
            // Pesan konfirmasi 
            DialogResult pesan = MessageBox.Show("Apa Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(pesan == DialogResult.Yes)
            {
                stokBarang stk = new stokBarang();
                stk.Delete(id_brg);
                // Method untuk menampilkan data yang telah terhapus ke dalam layar
                Tampil();
            }
        }

        private void tbl_dashboard2_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_stk2_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt2_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr2_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_prf2_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }
    }
}
