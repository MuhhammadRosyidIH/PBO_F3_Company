﻿namespace ProjectPBO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabel_stok = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.nama_barang = new System.Windows.Forms.TextBox();
            this.jumlah_barang = new System.Windows.Forms.TextBox();
            this.harga_barang = new System.Windows.Forms.TextBox();
            this.tombol_simpan = new System.Windows.Forms.Button();
            this.tombol_ubah = new System.Windows.Forms.Button();
            this.tombol_hapus = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.jenis_barang = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.tbl_ctt2 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tbl_prf2 = new System.Windows.Forms.Label();
            this.tbl_lpr2 = new System.Windows.Forms.Label();
            this.tbl_stk2 = new System.Windows.Forms.Label();
            this.tbl_dashboard2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.bg = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.jam = new System.Windows.Forms.Label();
            this.tanggalHariIni = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.tabel_stok)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.bg.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabel_stok
            // 
            this.tabel_stok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabel_stok.Location = new System.Drawing.Point(326, 362);
            this.tabel_stok.Name = "tabel_stok";
            this.tabel_stok.Size = new System.Drawing.Size(879, 270);
            this.tabel_stok.TabIndex = 0;
            this.tabel_stok.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tabel_stok_CellClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(7, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Data Stok Barang";
            // 
            // nama_barang
            // 
            this.nama_barang.Location = new System.Drawing.Point(441, 135);
            this.nama_barang.Name = "nama_barang";
            this.nama_barang.Size = new System.Drawing.Size(614, 20);
            this.nama_barang.TabIndex = 4;
            // 
            // jumlah_barang
            // 
            this.jumlah_barang.Location = new System.Drawing.Point(441, 176);
            this.jumlah_barang.Name = "jumlah_barang";
            this.jumlah_barang.Size = new System.Drawing.Size(614, 20);
            this.jumlah_barang.TabIndex = 5;
            // 
            // harga_barang
            // 
            this.harga_barang.Location = new System.Drawing.Point(441, 222);
            this.harga_barang.Name = "harga_barang";
            this.harga_barang.Size = new System.Drawing.Size(614, 20);
            this.harga_barang.TabIndex = 6;
            // 
            // tombol_simpan
            // 
            this.tombol_simpan.BackColor = System.Drawing.Color.LimeGreen;
            this.tombol_simpan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tombol_simpan.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tombol_simpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tombol_simpan.Location = new System.Drawing.Point(977, 309);
            this.tombol_simpan.Name = "tombol_simpan";
            this.tombol_simpan.Size = new System.Drawing.Size(277, 30);
            this.tombol_simpan.TabIndex = 7;
            this.tombol_simpan.Text = "SIMPAN";
            this.tombol_simpan.UseVisualStyleBackColor = false;
            this.tombol_simpan.Click += new System.EventHandler(this.tombol_simpan_Click);
            // 
            // tombol_ubah
            // 
            this.tombol_ubah.BackColor = System.Drawing.Color.LimeGreen;
            this.tombol_ubah.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tombol_ubah.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tombol_ubah.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tombol_ubah.Location = new System.Drawing.Point(826, 309);
            this.tombol_ubah.Name = "tombol_ubah";
            this.tombol_ubah.Size = new System.Drawing.Size(136, 30);
            this.tombol_ubah.TabIndex = 9;
            this.tombol_ubah.Text = "UBAH";
            this.tombol_ubah.UseVisualStyleBackColor = false;
            this.tombol_ubah.Click += new System.EventHandler(this.tombol_ubah_Click);
            // 
            // tombol_hapus
            // 
            this.tombol_hapus.BackColor = System.Drawing.Color.Firebrick;
            this.tombol_hapus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tombol_hapus.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tombol_hapus.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tombol_hapus.Location = new System.Drawing.Point(673, 309);
            this.tombol_hapus.Name = "tombol_hapus";
            this.tombol_hapus.Size = new System.Drawing.Size(135, 30);
            this.tombol_hapus.TabIndex = 10;
            this.tombol_hapus.Text = "HAPUS";
            this.tombol_hapus.UseVisualStyleBackColor = false;
            this.tombol_hapus.Click += new System.EventHandler(this.tombol_hapus_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(288, 263);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 22);
            this.label9.TabIndex = 11;
            this.label9.Text = "Jenis Barang";
            // 
            // jenis_barang
            // 
            this.jenis_barang.Location = new System.Drawing.Point(441, 267);
            this.jenis_barang.Name = "jenis_barang";
            this.jenis_barang.Size = new System.Drawing.Size(614, 20);
            this.jenis_barang.TabIndex = 12;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Coral;
            this.groupBox5.Controls.Add(this.pictureBox10);
            this.groupBox5.Controls.Add(this.pictureBox9);
            this.groupBox5.Controls.Add(this.pictureBox8);
            this.groupBox5.Controls.Add(this.pictureBox7);
            this.groupBox5.Controls.Add(this.pictureBox6);
            this.groupBox5.Controls.Add(this.tbl_ctt2);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Controls.Add(this.tbl_prf2);
            this.groupBox5.Controls.Add(this.tbl_lpr2);
            this.groupBox5.Controls.Add(this.tbl_stk2);
            this.groupBox5.Controls.Add(this.tbl_dashboard2);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Location = new System.Drawing.Point(-2, 68);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 683);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox10.Location = new System.Drawing.Point(63, 495);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox9.Location = new System.Drawing.Point(61, 442);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 21;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox8.Location = new System.Drawing.Point(61, 392);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox7.Location = new System.Drawing.Point(61, 347);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 23;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox6.Location = new System.Drawing.Point(61, 299);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // tbl_ctt2
            // 
            this.tbl_ctt2.AutoSize = true;
            this.tbl_ctt2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt2.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt2.Location = new System.Drawing.Point(91, 444);
            this.tbl_ctt2.Name = "tbl_ctt2";
            this.tbl_ctt2.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt2.TabIndex = 15;
            this.tbl_ctt2.Text = "Pencatatan";
            this.tbl_ctt2.Click += new System.EventHandler(this.tbl_ctt2_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox8.Location = new System.Drawing.Point(6, 384);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(10, 33);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            // 
            // tbl_prf2
            // 
            this.tbl_prf2.AutoSize = true;
            this.tbl_prf2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf2.ForeColor = System.Drawing.Color.White;
            this.tbl_prf2.Location = new System.Drawing.Point(89, 349);
            this.tbl_prf2.Name = "tbl_prf2";
            this.tbl_prf2.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf2.TabIndex = 17;
            this.tbl_prf2.Text = "Profil";
            this.tbl_prf2.Click += new System.EventHandler(this.tbl_prf2_Click);
            // 
            // tbl_lpr2
            // 
            this.tbl_lpr2.AutoSize = true;
            this.tbl_lpr2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr2.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr2.Location = new System.Drawing.Point(91, 497);
            this.tbl_lpr2.Name = "tbl_lpr2";
            this.tbl_lpr2.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr2.TabIndex = 16;
            this.tbl_lpr2.Text = "Laporan";
            this.tbl_lpr2.Click += new System.EventHandler(this.tbl_lpr2_Click);
            // 
            // tbl_stk2
            // 
            this.tbl_stk2.AutoSize = true;
            this.tbl_stk2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stk2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stk2.ForeColor = System.Drawing.Color.White;
            this.tbl_stk2.Location = new System.Drawing.Point(89, 394);
            this.tbl_stk2.Name = "tbl_stk2";
            this.tbl_stk2.Size = new System.Drawing.Size(103, 23);
            this.tbl_stk2.TabIndex = 14;
            this.tbl_stk2.Text = "Stok Barang";
            this.tbl_stk2.Click += new System.EventHandler(this.tbl_stk2_Click);
            // 
            // tbl_dashboard2
            // 
            this.tbl_dashboard2.AutoSize = true;
            this.tbl_dashboard2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard2.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard2.Location = new System.Drawing.Point(89, 301);
            this.tbl_dashboard2.Name = "tbl_dashboard2";
            this.tbl_dashboard2.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard2.TabIndex = 13;
            this.tbl_dashboard2.Text = "Dashboard";
            this.tbl_dashboard2.Click += new System.EventHandler(this.tbl_dashboard2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectPBO.Properties.Resources.r_letter_company_logo_9A44363CA1_seeklogo_com;
            this.pictureBox1.Location = new System.Drawing.Point(61, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Bisque;
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(0, 223);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(266, 57);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(89, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 31);
            this.label16.TabIndex = 18;
            this.label16.Text = "MENU";
            // 
            // bg
            // 
            this.bg.BackColor = System.Drawing.Color.PeachPuff;
            this.bg.Controls.Add(this.groupBox3);
            this.bg.Controls.Add(this.groupBox4);
            this.bg.Controls.Add(this.tabel_stok);
            this.bg.Controls.Add(this.jenis_barang);
            this.bg.Controls.Add(this.label9);
            this.bg.Controls.Add(this.tombol_hapus);
            this.bg.Controls.Add(this.label6);
            this.bg.Controls.Add(this.tombol_ubah);
            this.bg.Controls.Add(this.label7);
            this.bg.Controls.Add(this.label8);
            this.bg.Controls.Add(this.tombol_simpan);
            this.bg.Controls.Add(this.nama_barang);
            this.bg.Controls.Add(this.harga_barang);
            this.bg.Controls.Add(this.jumlah_barang);
            this.bg.Location = new System.Drawing.Point(-2, 0);
            this.bg.Name = "bg";
            this.bg.Size = new System.Drawing.Size(1372, 750);
            this.bg.TabIndex = 1;
            this.bg.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(264, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1005, 30);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.jam);
            this.groupBox4.Controls.Add(this.tanggalHariIni);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1274, 70);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGray;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(183, 31);
            this.label10.TabIndex = 15;
            this.label10.Text = "Aplikasi Reseler";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(288, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 22);
            this.label6.TabIndex = 1;
            this.label6.Text = "Nama Barang";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(288, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 22);
            this.label7.TabIndex = 2;
            this.label7.Text = "Jumlah Barang";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(288, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 22);
            this.label8.TabIndex = 3;
            this.label8.Text = "Harga Barang";
            // 
            // jam
            // 
            this.jam.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jam.ForeColor = System.Drawing.Color.White;
            this.jam.Location = new System.Drawing.Point(1112, 13);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(149, 21);
            this.jam.TabIndex = 9;
            this.jam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tanggalHariIni
            // 
            this.tanggalHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggalHariIni.ForeColor = System.Drawing.Color.White;
            this.tanggalHariIni.Location = new System.Drawing.Point(1147, 41);
            this.tanggalHariIni.Name = "tanggalHariIni";
            this.tanggalHariIni.Size = new System.Drawing.Size(115, 22);
            this.tanggalHariIni.TabIndex = 8;
            this.tanggalHariIni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.bg);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tabel_stok)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.bg.ResumeLayout(false);
            this.bg.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView TabelStok;
        private System.Windows.Forms.Button TombolKembali;
        private System.Windows.Forms.Button TombolHapus;
        private System.Windows.Forms.Button TombolUbah;
        private System.Windows.Forms.Button TombolSimpan;
        private System.Windows.Forms.TextBox HargaBarang;
        private System.Windows.Forms.TextBox JumlahStok;
        private System.Windows.Forms.TextBox NamaBarang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView tabel_stok;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox nama_barang;
        private System.Windows.Forms.TextBox jumlah_barang;
        private System.Windows.Forms.TextBox harga_barang;
        private System.Windows.Forms.Button tombol_simpan;
        private System.Windows.Forms.Button tombol_ubah;
        private System.Windows.Forms.Button tombol_hapus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox jenis_barang;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox bg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label tbl_ctt2;
        private System.Windows.Forms.Label tbl_prf2;
        private System.Windows.Forms.Label tbl_lpr2;
        private System.Windows.Forms.Label tbl_stk2;
        private System.Windows.Forms.Label tbl_dashboard2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label tanggalHariIni;
        private System.Windows.Forms.Timer timer1;
    }
}

