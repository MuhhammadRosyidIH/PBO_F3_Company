﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPBO.modelStokBarang
{
    class modelStok
    {
        string id_barang, nama_barang, stok_barang, harga_barang, jenis_barang;

        public modelStok() { }

        public modelStok(string id_barang, string nama_barang, string stok_barang, string harga_barang, string jenis_barang)
        {
            this.Id_barang = id_barang;
            this.Nama_barang = nama_barang;
            this.Stok_barang = stok_barang;
            this.Harga_barang = harga_barang;
            this.Jenis_barang = jenis_barang;
        }

        public string Id_barang { get => id_barang; set => id_barang = value; }
        public string Nama_barang { get => nama_barang; set => nama_barang = value; }
        public string Stok_barang { get => stok_barang; set => stok_barang = value; }
        public string Harga_barang { get => harga_barang; set => harga_barang = value; }
        public string Jenis_barang { get => jenis_barang; set => jenis_barang = value; }
    }
}
