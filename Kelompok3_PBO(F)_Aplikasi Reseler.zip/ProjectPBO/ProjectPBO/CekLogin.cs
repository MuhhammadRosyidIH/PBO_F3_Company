﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO
{
    class CekLogin
    {
        koneksi Koneksi = new koneksi();

        public bool cek_login(string email, string password)
        {
            try
            {
                Koneksi.OpenConnection();
                MySqlDataReader reader = Koneksi.reader("SELECT * FROM akun WHERE email='" +
                    email + "' AND password='" + password + "'");
                if (reader.Read())
                {
                    Koneksi.CloseConnection();
                    return true;
                }
                else
                {
                    Koneksi.CloseConnection();
                    return false;
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message, "Email atau password yang Anda masukkan salah");
            }
            return false;
        }
    }
}
