﻿namespace ProjectPBO
{
    partial class Profil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bg = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_logout = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.tbl_ctt5 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tbl_prf5 = new System.Windows.Forms.Label();
            this.tbl_lpr5 = new System.Windows.Forms.Label();
            this.tbl_stok5 = new System.Windows.Forms.Label();
            this.tbl_dashboard5 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbl_ctt2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbl_prf2 = new System.Windows.Forms.Label();
            this.tbl_lpr2 = new System.Windows.Forms.Label();
            this.tbl_stk2 = new System.Windows.Forms.Label();
            this.tbl_dashboard2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.jam = new System.Windows.Forms.Label();
            this.tanggalHariIni = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.bg.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Profil";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(50, 32);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1274, 70);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGray;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(9, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(183, 31);
            this.label10.TabIndex = 15;
            this.label10.Text = "Aplikasi Reseler";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(314, 102);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1005, 30);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            // 
            // bg
            // 
            this.bg.BackColor = System.Drawing.Color.PeachPuff;
            this.bg.Controls.Add(this.groupBox2);
            this.bg.Controls.Add(this.label11);
            this.bg.Controls.Add(this.label9);
            this.bg.Controls.Add(this.label8);
            this.bg.Controls.Add(this.label7);
            this.bg.Controls.Add(this.label6);
            this.bg.Controls.Add(this.label4);
            this.bg.Controls.Add(this.label3);
            this.bg.Controls.Add(this.label2);
            this.bg.Controls.Add(this.label1);
            this.bg.Controls.Add(this.pictureBox2);
            this.bg.Controls.Add(this.groupBox5);
            this.bg.Controls.Add(this.groupBox3);
            this.bg.Controls.Add(this.groupBox4);
            this.bg.Location = new System.Drawing.Point(-57, -38);
            this.bg.Name = "bg";
            this.bg.Size = new System.Drawing.Size(1372, 750);
            this.bg.TabIndex = 3;
            this.bg.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Controls.Add(this.btn_logout);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox10);
            this.groupBox2.Controls.Add(this.groupBox11);
            this.groupBox2.Location = new System.Drawing.Point(5, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1372, 750);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(460, 348);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(781, 312);
            this.dataGridView1.TabIndex = 38;
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.Firebrick;
            this.btn_logout.ForeColor = System.Drawing.Color.White;
            this.btn_logout.Location = new System.Drawing.Point(1171, 138);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(124, 34);
            this.btn_logout.TabIndex = 37;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox3.Location = new System.Drawing.Point(754, 169);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(160, 160);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Coral;
            this.groupBox6.Controls.Add(this.pictureBox4);
            this.groupBox6.Controls.Add(this.pictureBox5);
            this.groupBox6.Controls.Add(this.pictureBox11);
            this.groupBox6.Controls.Add(this.pictureBox12);
            this.groupBox6.Controls.Add(this.pictureBox13);
            this.groupBox6.Controls.Add(this.tbl_ctt5);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.tbl_prf5);
            this.groupBox6.Controls.Add(this.tbl_lpr5);
            this.groupBox6.Controls.Add(this.tbl_stok5);
            this.groupBox6.Controls.Add(this.tbl_dashboard5);
            this.groupBox6.Controls.Add(this.pictureBox14);
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Location = new System.Drawing.Point(51, 102);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(266, 683);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox4.Location = new System.Drawing.Point(60, 492);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(25, 25);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 20;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox5.Location = new System.Drawing.Point(58, 439);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox11.Location = new System.Drawing.Point(58, 389);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(25, 25);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 22;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox12.Location = new System.Drawing.Point(58, 344);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(25, 25);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 23;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox13.Location = new System.Drawing.Point(58, 296);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(25, 25);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 24;
            this.pictureBox13.TabStop = false;
            // 
            // tbl_ctt5
            // 
            this.tbl_ctt5.AutoSize = true;
            this.tbl_ctt5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt5.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt5.Location = new System.Drawing.Point(88, 441);
            this.tbl_ctt5.Name = "tbl_ctt5";
            this.tbl_ctt5.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt5.TabIndex = 15;
            this.tbl_ctt5.Text = "Pencatatan";
            this.tbl_ctt5.Click += new System.EventHandler(this.tbl_ctt5_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox8.Location = new System.Drawing.Point(3, 336);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(10, 33);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            // 
            // tbl_prf5
            // 
            this.tbl_prf5.AutoSize = true;
            this.tbl_prf5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf5.ForeColor = System.Drawing.Color.White;
            this.tbl_prf5.Location = new System.Drawing.Point(86, 346);
            this.tbl_prf5.Name = "tbl_prf5";
            this.tbl_prf5.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf5.TabIndex = 17;
            this.tbl_prf5.Text = "Profil";
            this.tbl_prf5.Click += new System.EventHandler(this.tbl_prf5_Click);
            // 
            // tbl_lpr5
            // 
            this.tbl_lpr5.AutoSize = true;
            this.tbl_lpr5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr5.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr5.Location = new System.Drawing.Point(88, 494);
            this.tbl_lpr5.Name = "tbl_lpr5";
            this.tbl_lpr5.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr5.TabIndex = 16;
            this.tbl_lpr5.Text = "Laporan";
            this.tbl_lpr5.Click += new System.EventHandler(this.tbl_lpr5_Click);
            // 
            // tbl_stok5
            // 
            this.tbl_stok5.AutoSize = true;
            this.tbl_stok5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stok5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stok5.ForeColor = System.Drawing.Color.White;
            this.tbl_stok5.Location = new System.Drawing.Point(86, 391);
            this.tbl_stok5.Name = "tbl_stok5";
            this.tbl_stok5.Size = new System.Drawing.Size(103, 23);
            this.tbl_stok5.TabIndex = 14;
            this.tbl_stok5.Text = "Stok Barang";
            this.tbl_stok5.Click += new System.EventHandler(this.tbl_stok5_Click);
            // 
            // tbl_dashboard5
            // 
            this.tbl_dashboard5.AutoSize = true;
            this.tbl_dashboard5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard5.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard5.Location = new System.Drawing.Point(86, 298);
            this.tbl_dashboard5.Name = "tbl_dashboard5";
            this.tbl_dashboard5.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard5.TabIndex = 13;
            this.tbl_dashboard5.Text = "Dashboard";
            this.tbl_dashboard5.Click += new System.EventHandler(this.tbl_dashboard5_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ProjectPBO.Properties.Resources.r_letter_company_logo_9A44363CA1_seeklogo_com;
            this.pictureBox14.Location = new System.Drawing.Point(58, 16);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(150, 150);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 10;
            this.pictureBox14.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.Bisque;
            this.groupBox9.Controls.Add(this.label29);
            this.groupBox9.Location = new System.Drawing.Point(-1, 220);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(266, 57);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(86, 11);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(79, 31);
            this.label29.TabIndex = 18;
            this.label29.Text = "MENU";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox10.Controls.Add(this.label30);
            this.groupBox10.Location = new System.Drawing.Point(314, 102);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1005, 30);
            this.groupBox10.TabIndex = 13;
            this.groupBox10.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(49, 23);
            this.label30.TabIndex = 0;
            this.label30.Text = "Profil";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox11.Controls.Add(this.jam);
            this.groupBox11.Controls.Add(this.tanggalHariIni);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Location = new System.Drawing.Point(50, 32);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1274, 70);
            this.groupBox11.TabIndex = 14;
            this.groupBox11.TabStop = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.DarkGray;
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(9, 13);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(183, 31);
            this.label31.TabIndex = 15;
            this.label31.Text = "Aplikasi Reseler";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(671, 569);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(146, 23);
            this.label11.TabIndex = 33;
            this.label11.Text = "arvito@gmail.com";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(671, 494);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 23);
            this.label9.TabIndex = 32;
            this.label9.Text = "08912345678";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(671, 427);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(226, 23);
            this.label8.TabIndex = 31;
            this.label8.Text = "Jl. Kapten Ilyas, Banyuwangi";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(671, 357);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 23);
            this.label7.TabIndex = 30;
            this.label7.Text = "Arvito Caesario A.P";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(441, 640);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 25);
            this.label6.TabIndex = 29;
            this.label6.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(441, 569);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 25);
            this.label4.TabIndex = 28;
            this.label4.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(441, 496);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "No HP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(441, 427);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 26;
            this.label2.Text = "Alamat";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(445, 357);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 25);
            this.label1.TabIndex = 25;
            this.label1.Text = "Nama";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox2.Location = new System.Drawing.Point(759, 174);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(160, 160);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Coral;
            this.groupBox5.Controls.Add(this.pictureBox10);
            this.groupBox5.Controls.Add(this.pictureBox9);
            this.groupBox5.Controls.Add(this.pictureBox8);
            this.groupBox5.Controls.Add(this.pictureBox7);
            this.groupBox5.Controls.Add(this.pictureBox6);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.tbl_ctt2);
            this.groupBox5.Controls.Add(this.groupBox1);
            this.groupBox5.Controls.Add(this.tbl_prf2);
            this.groupBox5.Controls.Add(this.tbl_lpr2);
            this.groupBox5.Controls.Add(this.tbl_stk2);
            this.groupBox5.Controls.Add(this.tbl_dashboard2);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Location = new System.Drawing.Point(51, 102);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 683);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox10.Location = new System.Drawing.Point(60, 492);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox9.Location = new System.Drawing.Point(58, 439);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 21;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox8.Location = new System.Drawing.Point(58, 389);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox7.Location = new System.Drawing.Point(58, 344);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 23;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox6.Location = new System.Drawing.Point(58, 296);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(52, 165);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(164, 31);
            this.label17.TabIndex = 19;
            this.label17.Text = "Nama Aplikasi";
            // 
            // tbl_ctt2
            // 
            this.tbl_ctt2.AutoSize = true;
            this.tbl_ctt2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt2.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt2.Location = new System.Drawing.Point(88, 441);
            this.tbl_ctt2.Name = "tbl_ctt2";
            this.tbl_ctt2.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt2.TabIndex = 15;
            this.tbl_ctt2.Text = "Pencatatan";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox1.Location = new System.Drawing.Point(3, 336);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(10, 33);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // tbl_prf2
            // 
            this.tbl_prf2.AutoSize = true;
            this.tbl_prf2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf2.ForeColor = System.Drawing.Color.White;
            this.tbl_prf2.Location = new System.Drawing.Point(86, 346);
            this.tbl_prf2.Name = "tbl_prf2";
            this.tbl_prf2.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf2.TabIndex = 17;
            this.tbl_prf2.Text = "Profil";
            // 
            // tbl_lpr2
            // 
            this.tbl_lpr2.AutoSize = true;
            this.tbl_lpr2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr2.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr2.Location = new System.Drawing.Point(88, 494);
            this.tbl_lpr2.Name = "tbl_lpr2";
            this.tbl_lpr2.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr2.TabIndex = 16;
            this.tbl_lpr2.Text = "Laporan";
            // 
            // tbl_stk2
            // 
            this.tbl_stk2.AutoSize = true;
            this.tbl_stk2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stk2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stk2.ForeColor = System.Drawing.Color.White;
            this.tbl_stk2.Location = new System.Drawing.Point(86, 391);
            this.tbl_stk2.Name = "tbl_stk2";
            this.tbl_stk2.Size = new System.Drawing.Size(103, 23);
            this.tbl_stk2.TabIndex = 14;
            this.tbl_stk2.Text = "Stok Barang";
            // 
            // tbl_dashboard2
            // 
            this.tbl_dashboard2.AutoSize = true;
            this.tbl_dashboard2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard2.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard2.Location = new System.Drawing.Point(86, 298);
            this.tbl_dashboard2.Name = "tbl_dashboard2";
            this.tbl_dashboard2.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard2.TabIndex = 13;
            this.tbl_dashboard2.Text = "Dashboard";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(68, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 130);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(-3, 220);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(266, 57);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(86, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 31);
            this.label16.TabIndex = 18;
            this.label16.Text = "MENU";
            // 
            // jam
            // 
            this.jam.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jam.ForeColor = System.Drawing.Color.White;
            this.jam.Location = new System.Drawing.Point(1112, 13);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(149, 21);
            this.jam.TabIndex = 9;
            this.jam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tanggalHariIni
            // 
            this.tanggalHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggalHariIni.ForeColor = System.Drawing.Color.White;
            this.tanggalHariIni.Location = new System.Drawing.Point(1147, 41);
            this.tanggalHariIni.Name = "tanggalHariIni";
            this.tanggalHariIni.Size = new System.Drawing.Size(115, 22);
            this.tanggalHariIni.TabIndex = 8;
            this.tanggalHariIni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Profil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.bg);
            this.Name = "Profil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Profil";
            this.Load += new System.EventHandler(this.Profil_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.bg.ResumeLayout(false);
            this.bg.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox bg;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label tbl_ctt5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label tbl_prf5;
        private System.Windows.Forms.Label tbl_lpr5;
        private System.Windows.Forms.Label tbl_stok5;
        private System.Windows.Forms.Label tbl_dashboard5;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label tbl_ctt2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label tbl_prf2;
        private System.Windows.Forms.Label tbl_lpr2;
        private System.Windows.Forms.Label tbl_stk2;
        private System.Windows.Forms.Label tbl_dashboard2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label tanggalHariIni;
        private System.Windows.Forms.Timer timer1;
    }
}