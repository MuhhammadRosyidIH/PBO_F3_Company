﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO
{
    public partial class Login : Form
    {
        CekLogin Cek_login = new CekLogin();

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(tbl_email.Text == "" || tbl_pass.Text == "")
            {
                MessageBox.Show("Harap isi email atau password terlebih dahulu", "Gagal");
            }
            else
            {
                string email = tbl_email.Text;
                string password = tbl_pass.Text;

                bool status = Cek_login.cek_login(email, password);
                if (status)
                {
                    MessageBox.Show("Login berhasil", "Berhasil");
                    Beranda beranda = new Beranda();
                    beranda.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Email atau password salah", "Gagal");
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            tbl_pass.UseSystemPasswordChar = true;
        }

        private void lihatPass_CheckedChanged(object sender, EventArgs e)
        {
            if (lihatPass.Checked)
            {
                tbl_pass.UseSystemPasswordChar = false;
            }
            else
            {
                tbl_pass.UseSystemPasswordChar = true;
            }
        }
    }
}
