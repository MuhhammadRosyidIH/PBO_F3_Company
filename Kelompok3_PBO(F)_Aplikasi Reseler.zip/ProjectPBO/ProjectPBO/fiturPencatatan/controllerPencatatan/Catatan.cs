﻿using ProjectPBO.fiturPencatatan.modelPencatatan;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO.fiturPencatatan.controllerPencatatan
{
    class Catatan
    {
        //Memanggil class koneksi dan variabel baru
        koneksi Koneksi = new koneksi();

        //Metode insert
        public bool Insert(modelCatatan catatan)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("INSERT INTO transaksi (pemasukan, pengeluaran, tanggal, jumlah_barang_masuk, jumlah_barang_keluar, metode_pembayaran) VALUES ('" + catatan.Pemasukan + "', '" + catatan.Pengeluaran + "', '" + catatan.Tanggal + "', '" + catatan.Jumlah_barang_masuk + "', '" + catatan.Jumlah_barang_keluar + "', '" + catatan.Metode_pembayaran + "')");                
                status = true;
                MessageBox.Show("Data Laporan berhasil ditambahkan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }

        public bool Update(modelCatatan catatan, string id_trk)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("UPDATE transaksi SET tanggal='" + catatan.Tanggal + "', "+ "pemasukan='" + catatan.Pemasukan + "', " + "pengeluaran='" + catatan.Pengeluaran + "', " + "jumlah_barang_masuk='" + catatan.Jumlah_barang_masuk + "', " + "jumlah_barang_keluar='" + catatan.Jumlah_barang_keluar+"'," +"metode_pembayaran='" +catatan.Metode_pembayaran+"' WHERE id_transaksi='" + id_trk + "'");
                status = true;
                MessageBox.Show("Data laporan berhasil diubah", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }

        public bool Delete(string id_trk)
        {
            Boolean status = false;
            try
            {
                Koneksi.OpenConnection();
                Koneksi.ExecuteQuery("DELETE FROM transaksi WHERE id_transaksi='" + id_trk + "'");
                status = true;
                MessageBox.Show("Data transaksi berhasil dihapus", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Koneksi.CloseConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return status;
        }
    }
}
