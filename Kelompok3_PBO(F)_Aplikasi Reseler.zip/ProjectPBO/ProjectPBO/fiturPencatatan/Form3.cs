﻿using ProjectPBO.fiturLaporan;
using ProjectPBO.fiturPencatatan.viewPencatatan;
using ProjectPBO.fiturPencatatan.controllerPencatatan;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectPBO.fiturPencatatan.modelPencatatan;
using DGVPrinterHelper;

namespace ProjectPBO
{
    public partial class Form3 : Form
    {
        // Memanggil class koneksi untuk menghubungkan ke database
        koneksi Koneksi = new koneksi();
        modelCatatan catatan = new modelCatatan();
        string id_trk;

        public Form3()
        {
            InitializeComponent();
        }

        public void Tampil_laporan()
        {
            // Query database
            tabelLaporan.DataSource = Koneksi.ShowData("SELECT * FROM transaksi");
            //Mengubah nama kolom
            tabelLaporan.Columns[0].HeaderText = "NO";
            tabelLaporan.Columns[1].HeaderText = "TANGGAL";
            tabelLaporan.Columns[2].HeaderText = "PEMASUKAN";
            tabelLaporan.Columns[3].HeaderText = "PENGELUARAN";
            tabelLaporan.Columns[4].HeaderText = "PEMBAYARAN";
            tabelLaporan.Columns[5].HeaderText = "BARANG MASUK";
            tabelLaporan.Columns[6].HeaderText = "BARANG KELUAR";
        }

        private void tbl_dashboard4_Click(object sender, EventArgs e)
        {
            // Masuk beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_stk4_Click(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt4_Click(object sender, EventArgs e)
        {
            // Masuk pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr4_Click(object sender, EventArgs e)
        {
            // Masuk laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_prf4_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void btn_pensil_Click(object sender, EventArgs e)
        {
            // Masuk Edit laporan
            editLaporan edit = new editLaporan();
            edit.Show();
            this.Hide();
        }

        private void cetakLaporan_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Rekapan Laporan Transaksi Penjualan";
            printer.Title = "====== Perusahaan Company ======";
            printer.SubTitle = string.Format(DateTime.Now.Date.ToString("dddd-MMMM-yyyy"));
            printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.PorportionalColumns = true;
            printer.HeaderCellAlignment = StringAlignment.Near;
            printer.FooterSpacing = 15;
            printer.PrintPreviewDataGridView(tabelLaporan);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }

        private void Form3_Load_1(object sender, EventArgs e)
        {
            //Panggil database
            Tampil_laporan();
            timer1.Start();
        }
    }
}
