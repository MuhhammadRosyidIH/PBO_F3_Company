﻿namespace ProjectPBO
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbl_ctt4 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tbl_prf4 = new System.Windows.Forms.Label();
            this.tbl_lpr4 = new System.Windows.Forms.Label();
            this.tbl_stk4 = new System.Windows.Forms.Label();
            this.tbl_dashboard4 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.jam = new System.Windows.Forms.Label();
            this.tanggalHariIni = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabelLaporan = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cetakLaporan = new System.Windows.Forms.PictureBox();
            this.btn_pensil = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabelLaporan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cetakLaporan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_pensil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox1.Controls.Add(this.cetakLaporan);
            this.groupBox1.Controls.Add(this.tabelLaporan);
            this.groupBox1.Controls.Add(this.btn_pensil);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Location = new System.Drawing.Point(-1, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1267, 681);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Coral;
            this.groupBox5.Controls.Add(this.pictureBox10);
            this.groupBox5.Controls.Add(this.pictureBox9);
            this.groupBox5.Controls.Add(this.tbl_ctt4);
            this.groupBox5.Controls.Add(this.pictureBox8);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.pictureBox7);
            this.groupBox5.Controls.Add(this.pictureBox6);
            this.groupBox5.Controls.Add(this.tbl_prf4);
            this.groupBox5.Controls.Add(this.tbl_lpr4);
            this.groupBox5.Controls.Add(this.tbl_stk4);
            this.groupBox5.Controls.Add(this.tbl_dashboard4);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Location = new System.Drawing.Point(0, 70);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 683);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            // 
            // tbl_ctt4
            // 
            this.tbl_ctt4.AutoSize = true;
            this.tbl_ctt4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt4.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt4.Location = new System.Drawing.Point(91, 444);
            this.tbl_ctt4.Name = "tbl_ctt4";
            this.tbl_ctt4.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt4.TabIndex = 15;
            this.tbl_ctt4.Text = "Pencatatan";
            this.tbl_ctt4.Click += new System.EventHandler(this.tbl_ctt4_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox6.Location = new System.Drawing.Point(6, 487);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(10, 33);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            // 
            // tbl_prf4
            // 
            this.tbl_prf4.AutoSize = true;
            this.tbl_prf4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf4.ForeColor = System.Drawing.Color.White;
            this.tbl_prf4.Location = new System.Drawing.Point(89, 349);
            this.tbl_prf4.Name = "tbl_prf4";
            this.tbl_prf4.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf4.TabIndex = 17;
            this.tbl_prf4.Text = "Profil";
            this.tbl_prf4.Click += new System.EventHandler(this.tbl_prf4_Click);
            // 
            // tbl_lpr4
            // 
            this.tbl_lpr4.AutoSize = true;
            this.tbl_lpr4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr4.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr4.Location = new System.Drawing.Point(91, 497);
            this.tbl_lpr4.Name = "tbl_lpr4";
            this.tbl_lpr4.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr4.TabIndex = 16;
            this.tbl_lpr4.Text = "Laporan";
            this.tbl_lpr4.Click += new System.EventHandler(this.tbl_lpr4_Click);
            // 
            // tbl_stk4
            // 
            this.tbl_stk4.AutoSize = true;
            this.tbl_stk4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stk4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stk4.ForeColor = System.Drawing.Color.White;
            this.tbl_stk4.Location = new System.Drawing.Point(89, 394);
            this.tbl_stk4.Name = "tbl_stk4";
            this.tbl_stk4.Size = new System.Drawing.Size(103, 23);
            this.tbl_stk4.TabIndex = 14;
            this.tbl_stk4.Text = "Stok Barang";
            this.tbl_stk4.Click += new System.EventHandler(this.tbl_stk4_Click);
            // 
            // tbl_dashboard4
            // 
            this.tbl_dashboard4.AutoSize = true;
            this.tbl_dashboard4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard4.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard4.Location = new System.Drawing.Point(89, 301);
            this.tbl_dashboard4.Name = "tbl_dashboard4";
            this.tbl_dashboard4.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard4.TabIndex = 13;
            this.tbl_dashboard4.Text = "Dashboard";
            this.tbl_dashboard4.Click += new System.EventHandler(this.tbl_dashboard4_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(0, 223);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(266, 57);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(89, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 31);
            this.label16.TabIndex = 18;
            this.label16.Text = "MENU";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(264, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1005, 30);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(7, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Data Laporan";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.jam);
            this.groupBox4.Controls.Add(this.tanggalHariIni);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1274, 70);
            this.groupBox4.TabIndex = 19;
            this.groupBox4.TabStop = false;
            // 
            // jam
            // 
            this.jam.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jam.ForeColor = System.Drawing.Color.White;
            this.jam.Location = new System.Drawing.Point(1112, 13);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(149, 21);
            this.jam.TabIndex = 9;
            this.jam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tanggalHariIni
            // 
            this.tanggalHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggalHariIni.ForeColor = System.Drawing.Color.White;
            this.tanggalHariIni.Location = new System.Drawing.Point(1147, 41);
            this.tanggalHariIni.Name = "tanggalHariIni";
            this.tanggalHariIni.Size = new System.Drawing.Size(115, 22);
            this.tanggalHariIni.TabIndex = 8;
            this.tanggalHariIni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGray;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(183, 31);
            this.label10.TabIndex = 15;
            this.label10.Text = "Aplikasi Reseler";
            // 
            // tabelLaporan
            // 
            this.tabelLaporan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabelLaporan.Location = new System.Drawing.Point(416, 221);
            this.tabelLaporan.Name = "tabelLaporan";
            this.tabelLaporan.Size = new System.Drawing.Size(741, 356);
            this.tabelLaporan.TabIndex = 27;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cetakLaporan
            // 
            this.cetakLaporan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cetakLaporan.Image = global::ProjectPBO.Properties.Resources.print_flat;
            this.cetakLaporan.Location = new System.Drawing.Point(1151, 121);
            this.cetakLaporan.Name = "cetakLaporan";
            this.cetakLaporan.Size = new System.Drawing.Size(40, 40);
            this.cetakLaporan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cetakLaporan.TabIndex = 28;
            this.cetakLaporan.TabStop = false;
            this.cetakLaporan.Click += new System.EventHandler(this.cetakLaporan_Click);
            // 
            // btn_pensil
            // 
            this.btn_pensil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pensil.Image = global::ProjectPBO.Properties.Resources.edit_icon_2375785_1280;
            this.btn_pensil.Location = new System.Drawing.Point(1198, 121);
            this.btn_pensil.Name = "btn_pensil";
            this.btn_pensil.Size = new System.Drawing.Size(40, 40);
            this.btn_pensil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_pensil.TabIndex = 26;
            this.btn_pensil.TabStop = false;
            this.btn_pensil.Click += new System.EventHandler(this.btn_pensil_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox10.Location = new System.Drawing.Point(63, 495);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 21;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox9.Location = new System.Drawing.Point(61, 442);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 22;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox8.Location = new System.Drawing.Point(61, 392);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 23;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox7.Location = new System.Drawing.Point(61, 347);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 24;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox6.Location = new System.Drawing.Point(61, 299);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 25;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectPBO.Properties.Resources.r_letter_company_logo_9A44363CA1_seeklogo_com;
            this.pictureBox1.Location = new System.Drawing.Point(61, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load_1);
            this.groupBox1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabelLaporan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cetakLaporan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_pensil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label tbl_ctt4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label tbl_prf4;
        private System.Windows.Forms.Label tbl_lpr4;
        private System.Windows.Forms.Label tbl_stk4;
        private System.Windows.Forms.Label tbl_dashboard4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox btn_pensil;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label tanggalHariIni;
        private System.Windows.Forms.PictureBox cetakLaporan;
        private System.Windows.Forms.DataGridView tabelLaporan;
        private System.Windows.Forms.Timer timer1;
    }
}