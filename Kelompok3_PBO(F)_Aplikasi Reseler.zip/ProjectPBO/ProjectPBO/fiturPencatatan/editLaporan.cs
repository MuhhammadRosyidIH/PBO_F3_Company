﻿using System;
using ProjectPBO.fiturLaporan;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectPBO.fiturPencatatan.viewPencatatan;
using ProjectPBO.fiturPencatatan.modelPencatatan;
using ProjectPBO.fiturPencatatan.controllerPencatatan;

namespace ProjectPBO.fiturLaporan
{
    public partial class editLaporan : Form
    {
        koneksi Koneksi = new koneksi();
        modelCatatan catatan = new modelCatatan();
        string id_trk;

        public editLaporan()
        {
            InitializeComponent();
        }
        public void Tampil_edit_laporan()
        {
            // Query database
            tabelEdit.DataSource = Koneksi.ShowData("SELECT * FROM transaksi");
            //Mengubah nama kolom
            tabelEdit.Columns[0].HeaderText = "NO";
            tabelEdit.Columns[1].HeaderText = "TANGGAL";
            tabelEdit.Columns[2].HeaderText = "PEMASUKAN";
            tabelEdit.Columns[3].HeaderText = "PENGELUARAN";
            tabelEdit.Columns[4].HeaderText = "PEMBAYARAN";
            tabelEdit.Columns[5].HeaderText = "BARANG MASUK";
            tabelEdit.Columns[6].HeaderText = "BARANG KELUAR";
        }
        private void editLaporan_Load(object sender, EventArgs e)
        {
            // Panggil method tampil
            Tampil_edit_laporan();
            timer1.Start();
        }

        private void tabelEdit_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Untuk memilih data yang ingin dihapus berdasarkan id nya
            id_trk = tabelEdit.Rows[e.RowIndex].Cells[0].Value.ToString();
            tgl2.Text = tabelEdit.Rows[e.RowIndex].Cells[1].Value.ToString();
            pm2.Text = tabelEdit.Rows[e.RowIndex].Cells[2].Value.ToString();
            pg2.Text = tabelEdit.Rows[e.RowIndex].Cells[3].Value.ToString();
            metode2.Text = tabelEdit.Rows[e.RowIndex].Cells[4].Value.ToString();
            masuk2.Text = tabelEdit.Rows[e.RowIndex].Cells[5].Value.ToString();
            keluar2.Text = tabelEdit.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void btn_ubah_Click(object sender, EventArgs e)
        {
            // Cek seluruh value yang ada pada textbox, jika kosong akan 
            // menampilkan message seperti dibawah
            if (pm2.Text == "" || pg2.Text == "" || tgl2.Text == "" || metode2.Text == "" || masuk2.Text == "" || keluar2.Text == "")
            {
                MessageBox.Show("Harap isi dulu!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // Jika telah terisi value kita dapat memasukkannya ke dalam sistem class Catatan 
                // kemudian diteruskan ke database dengan menggunakan query insert pada class tersebut
                Catatan ctt = new Catatan();
                catatan.Pemasukan = pm2.Text;
                catatan.Pengeluaran = pg2.Text;
                catatan.Tanggal = tgl2.Text;
                catatan.Metode_pembayaran = metode2.Text;
                catatan.Jumlah_barang_masuk = masuk2.Text;
                catatan.Jumlah_barang_keluar = keluar2.Text;
               

                ctt.Update(catatan,id_trk);
                pm2.Text = "";
                pg2.Text = "";
                tgl2.Text = "";
                metode2.SelectedIndex = -1;
                masuk2.Text = "";
                keluar2.Text = "";
                Tampil_edit_laporan();
            }
        }

        private void btn_hapus_Click(object sender, EventArgs e)
        {
            // Untuk menghapus data sesuai id nya
            // Pesan konfirmasi 
            DialogResult pesan = MessageBox.Show("Apa Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (pesan == DialogResult.Yes)
            {
                Catatan ctt = new Catatan();
                ctt.Delete(id_trk);
                // Method untuk menampilkan data yang telah terhapus ke dalam layar
                Tampil_edit_laporan();
            }
        }

        private void tbl_dashboard3_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_prf3_Click(object sender, EventArgs e)
        {
            // Masuk Beranda
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void tbl_stk3_Click(object sender, EventArgs e)
        {
            // Masuk Stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt3_Click(object sender, EventArgs e)
        {
            // Masuk Pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr3_Click(object sender, EventArgs e)
        {
            // Masuk Laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }


    }
}
