﻿namespace ProjectPBO.fiturPencatatan.viewPencatatan
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_pm = new System.Windows.Forms.Label();
            this.label_pg = new System.Windows.Forms.Label();
            this.label_tgl = new System.Windows.Forms.Label();
            this.tbl_simpan = new System.Windows.Forms.Button();
            this.metode = new System.Windows.Forms.ComboBox();
            this.tgl = new System.Windows.Forms.DateTimePicker();
            this.keluar = new System.Windows.Forms.TextBox();
            this.masuk = new System.Windows.Forms.TextBox();
            this.pm = new System.Windows.Forms.TextBox();
            this.pg = new System.Windows.Forms.TextBox();
            this.label_metode = new System.Windows.Forms.Label();
            this.label_keluar = new System.Windows.Forms.Label();
            this.label_masuk = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.tbl_ctt3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbl_prf3 = new System.Windows.Forms.Label();
            this.tbl_lpr3 = new System.Windows.Forms.Label();
            this.tbl_stk3 = new System.Windows.Forms.Label();
            this.tbl_dashboard3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.jam = new System.Windows.Forms.Label();
            this.tanggalHariIni = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_pm
            // 
            this.label_pm.AutoSize = true;
            this.label_pm.BackColor = System.Drawing.Color.PeachPuff;
            this.label_pm.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pm.Location = new System.Drawing.Point(460, 153);
            this.label_pm.Name = "label_pm";
            this.label_pm.Size = new System.Drawing.Size(109, 22);
            this.label_pm.TabIndex = 1;
            this.label_pm.Text = "Pemasukan";
            // 
            // label_pg
            // 
            this.label_pg.AutoSize = true;
            this.label_pg.BackColor = System.Drawing.Color.PeachPuff;
            this.label_pg.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pg.Location = new System.Drawing.Point(970, 153);
            this.label_pg.Name = "label_pg";
            this.label_pg.Size = new System.Drawing.Size(116, 22);
            this.label_pg.TabIndex = 2;
            this.label_pg.Text = "Pengeluaran";
            // 
            // label_tgl
            // 
            this.label_tgl.AutoSize = true;
            this.label_tgl.BackColor = System.Drawing.Color.PeachPuff;
            this.label_tgl.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_tgl.Location = new System.Drawing.Point(460, 251);
            this.label_tgl.Name = "label_tgl";
            this.label_tgl.Size = new System.Drawing.Size(76, 22);
            this.label_tgl.TabIndex = 3;
            this.label_tgl.Text = "Tanggal";
            // 
            // tbl_simpan
            // 
            this.tbl_simpan.BackColor = System.Drawing.Color.LimeGreen;
            this.tbl_simpan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_simpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tbl_simpan.Location = new System.Drawing.Point(936, 514);
            this.tbl_simpan.Name = "tbl_simpan";
            this.tbl_simpan.Size = new System.Drawing.Size(150, 30);
            this.tbl_simpan.TabIndex = 13;
            this.tbl_simpan.Text = "SIMPAN";
            this.tbl_simpan.UseVisualStyleBackColor = false;
            this.tbl_simpan.Click += new System.EventHandler(this.tbl_simpan_Click);
            // 
            // metode
            // 
            this.metode.FormattingEnabled = true;
            this.metode.Location = new System.Drawing.Point(689, 430);
            this.metode.Name = "metode";
            this.metode.Size = new System.Drawing.Size(177, 21);
            this.metode.TabIndex = 12;
            // 
            // tgl
            // 
            this.tgl.Location = new System.Drawing.Point(689, 253);
            this.tgl.Name = "tgl";
            this.tgl.Size = new System.Drawing.Size(397, 20);
            this.tgl.TabIndex = 11;
            // 
            // keluar
            // 
            this.keluar.Location = new System.Drawing.Point(689, 371);
            this.keluar.Name = "keluar";
            this.keluar.Size = new System.Drawing.Size(397, 20);
            this.keluar.TabIndex = 10;
            // 
            // masuk
            // 
            this.masuk.Location = new System.Drawing.Point(689, 311);
            this.masuk.Name = "masuk";
            this.masuk.Size = new System.Drawing.Size(397, 20);
            this.masuk.TabIndex = 9;
            // 
            // pm
            // 
            this.pm.Location = new System.Drawing.Point(464, 190);
            this.pm.Name = "pm";
            this.pm.Size = new System.Drawing.Size(309, 20);
            this.pm.TabIndex = 8;
            // 
            // pg
            // 
            this.pg.Location = new System.Drawing.Point(776, 190);
            this.pg.Name = "pg";
            this.pg.Size = new System.Drawing.Size(310, 20);
            this.pg.TabIndex = 7;
            // 
            // label_metode
            // 
            this.label_metode.AutoSize = true;
            this.label_metode.BackColor = System.Drawing.Color.PeachPuff;
            this.label_metode.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_metode.Location = new System.Drawing.Point(460, 429);
            this.label_metode.Name = "label_metode";
            this.label_metode.Size = new System.Drawing.Size(183, 22);
            this.label_metode.TabIndex = 6;
            this.label_metode.Text = "Metode pembayaran";
            // 
            // label_keluar
            // 
            this.label_keluar.AutoSize = true;
            this.label_keluar.BackColor = System.Drawing.Color.PeachPuff;
            this.label_keluar.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_keluar.Location = new System.Drawing.Point(460, 369);
            this.label_keluar.Name = "label_keluar";
            this.label_keluar.Size = new System.Drawing.Size(188, 22);
            this.label_keluar.TabIndex = 5;
            this.label_keluar.Text = "Jumlah barang keluar";
            // 
            // label_masuk
            // 
            this.label_masuk.AutoSize = true;
            this.label_masuk.BackColor = System.Drawing.Color.PeachPuff;
            this.label_masuk.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_masuk.Location = new System.Drawing.Point(460, 307);
            this.label_masuk.Name = "label_masuk";
            this.label_masuk.Size = new System.Drawing.Size(193, 22);
            this.label_masuk.TabIndex = 4;
            this.label_masuk.Text = "Jumlah barang masuk";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.tbl_simpan);
            this.groupBox1.Controls.Add(this.label_pm);
            this.groupBox1.Controls.Add(this.keluar);
            this.groupBox1.Controls.Add(this.metode);
            this.groupBox1.Controls.Add(this.masuk);
            this.groupBox1.Controls.Add(this.label_pg);
            this.groupBox1.Controls.Add(this.tgl);
            this.groupBox1.Controls.Add(this.pm);
            this.groupBox1.Controls.Add(this.label_metode);
            this.groupBox1.Controls.Add(this.pg);
            this.groupBox1.Controls.Add(this.label_keluar);
            this.groupBox1.Controls.Add(this.label_masuk);
            this.groupBox1.Controls.Add(this.label_tgl);
            this.groupBox1.Location = new System.Drawing.Point(-1, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1370, 750);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Coral;
            this.groupBox5.Controls.Add(this.pictureBox10);
            this.groupBox5.Controls.Add(this.pictureBox9);
            this.groupBox5.Controls.Add(this.pictureBox8);
            this.groupBox5.Controls.Add(this.pictureBox7);
            this.groupBox5.Controls.Add(this.pictureBox6);
            this.groupBox5.Controls.Add(this.tbl_ctt3);
            this.groupBox5.Controls.Add(this.groupBox2);
            this.groupBox5.Controls.Add(this.tbl_prf3);
            this.groupBox5.Controls.Add(this.tbl_lpr3);
            this.groupBox5.Controls.Add(this.tbl_stk3);
            this.groupBox5.Controls.Add(this.tbl_dashboard3);
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Location = new System.Drawing.Point(0, 70);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 683);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProjectPBO.Properties.Resources.laporan2;
            this.pictureBox10.Location = new System.Drawing.Point(63, 495);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 20;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProjectPBO.Properties.Resources.laporan;
            this.pictureBox9.Location = new System.Drawing.Point(61, 442);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 21;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProjectPBO.Properties.Resources.stok;
            this.pictureBox8.Location = new System.Drawing.Point(61, 392);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProjectPBO.Properties.Resources.profile;
            this.pictureBox7.Location = new System.Drawing.Point(61, 347);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 25);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 23;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProjectPBO.Properties.Resources.home_icon;
            this.pictureBox6.Location = new System.Drawing.Point(61, 299);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // tbl_ctt3
            // 
            this.tbl_ctt3.AutoSize = true;
            this.tbl_ctt3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_ctt3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_ctt3.ForeColor = System.Drawing.Color.White;
            this.tbl_ctt3.Location = new System.Drawing.Point(91, 444);
            this.tbl_ctt3.Name = "tbl_ctt3";
            this.tbl_ctt3.Size = new System.Drawing.Size(95, 23);
            this.tbl_ctt3.TabIndex = 15;
            this.tbl_ctt3.Text = "Pencatatan";
            this.tbl_ctt3.Click += new System.EventHandler(this.tbl_ctt3_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox2.Location = new System.Drawing.Point(6, 434);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(10, 33);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // tbl_prf3
            // 
            this.tbl_prf3.AutoSize = true;
            this.tbl_prf3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_prf3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_prf3.ForeColor = System.Drawing.Color.White;
            this.tbl_prf3.Location = new System.Drawing.Point(89, 349);
            this.tbl_prf3.Name = "tbl_prf3";
            this.tbl_prf3.Size = new System.Drawing.Size(49, 23);
            this.tbl_prf3.TabIndex = 17;
            this.tbl_prf3.Text = "Profil";
            this.tbl_prf3.Click += new System.EventHandler(this.tbl_prf3_Click);
            // 
            // tbl_lpr3
            // 
            this.tbl_lpr3.AutoSize = true;
            this.tbl_lpr3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_lpr3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_lpr3.ForeColor = System.Drawing.Color.White;
            this.tbl_lpr3.Location = new System.Drawing.Point(91, 497);
            this.tbl_lpr3.Name = "tbl_lpr3";
            this.tbl_lpr3.Size = new System.Drawing.Size(74, 23);
            this.tbl_lpr3.TabIndex = 16;
            this.tbl_lpr3.Text = "Laporan";
            this.tbl_lpr3.Click += new System.EventHandler(this.tbl_lpr3_Click);
            // 
            // tbl_stk3
            // 
            this.tbl_stk3.AutoSize = true;
            this.tbl_stk3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_stk3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_stk3.ForeColor = System.Drawing.Color.White;
            this.tbl_stk3.Location = new System.Drawing.Point(89, 394);
            this.tbl_stk3.Name = "tbl_stk3";
            this.tbl_stk3.Size = new System.Drawing.Size(103, 23);
            this.tbl_stk3.TabIndex = 14;
            this.tbl_stk3.Text = "Stok Barang";
            this.tbl_stk3.Click += new System.EventHandler(this.tbl_stk3_Click);
            // 
            // tbl_dashboard3
            // 
            this.tbl_dashboard3.AutoSize = true;
            this.tbl_dashboard3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbl_dashboard3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_dashboard3.ForeColor = System.Drawing.Color.White;
            this.tbl_dashboard3.Location = new System.Drawing.Point(89, 301);
            this.tbl_dashboard3.Name = "tbl_dashboard3";
            this.tbl_dashboard3.Size = new System.Drawing.Size(94, 23);
            this.tbl_dashboard3.TabIndex = 13;
            this.tbl_dashboard3.Text = "Dashboard";
            this.tbl_dashboard3.Click += new System.EventHandler(this.tbl_dashboard3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectPBO.Properties.Resources.r_letter_company_logo_9A44363CA1_seeklogo_com;
            this.pictureBox1.Location = new System.Drawing.Point(61, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Bisque;
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(0, 223);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(266, 57);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(89, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 31);
            this.label16.TabIndex = 18;
            this.label16.Text = "MENU";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(264, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1005, 30);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(7, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Form Laporan";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.jam);
            this.groupBox4.Controls.Add(this.tanggalHariIni);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1274, 70);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGray;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(183, 31);
            this.label10.TabIndex = 15;
            this.label10.Text = "Aplikasi Reseler";
            // 
            // jam
            // 
            this.jam.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jam.ForeColor = System.Drawing.Color.White;
            this.jam.Location = new System.Drawing.Point(1112, 13);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(149, 21);
            this.jam.TabIndex = 18;
            this.jam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tanggalHariIni
            // 
            this.tanggalHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tanggalHariIni.ForeColor = System.Drawing.Color.White;
            this.tanggalHariIni.Location = new System.Drawing.Point(1147, 41);
            this.tanggalHariIni.Name = "tanggalHariIni";
            this.tanggalHariIni.Size = new System.Drawing.Size(115, 22);
            this.tanggalHariIni.TabIndex = 17;
            this.tanggalHariIni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label_pm;
        private System.Windows.Forms.Label label_pg;
        private System.Windows.Forms.Label label_tgl;
        private System.Windows.Forms.Button tbl_simpan;
        private System.Windows.Forms.ComboBox metode;
        private System.Windows.Forms.DateTimePicker tgl;
        private System.Windows.Forms.TextBox keluar;
        private System.Windows.Forms.TextBox masuk;
        private System.Windows.Forms.TextBox pm;
        private System.Windows.Forms.TextBox pg;
        private System.Windows.Forms.Label label_metode;
        private System.Windows.Forms.Label label_keluar;
        private System.Windows.Forms.Label label_masuk;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label tbl_ctt3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label tbl_prf3;
        private System.Windows.Forms.Label tbl_lpr3;
        private System.Windows.Forms.Label tbl_stk3;
        private System.Windows.Forms.Label tbl_dashboard3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label tanggalHariIni;
        private System.Windows.Forms.Timer timer1;
    }
}