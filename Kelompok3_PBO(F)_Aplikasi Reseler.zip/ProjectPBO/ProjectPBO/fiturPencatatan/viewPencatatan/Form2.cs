﻿using ProjectPBO.fiturPencatatan.controllerPencatatan;
using ProjectPBO.fiturPencatatan.modelPencatatan;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO.fiturPencatatan.viewPencatatan
{
    public partial class Form2 : Form
    {
        // Panggil class koneksi dan modelCatatan untuk menghubungkan ke database dan sistem
        // yang ada pada fitur pencatatan
        koneksi Koneski = new koneksi();
        modelCatatan catatan = new modelCatatan();

        public Form2()
        {
            InitializeComponent();
        }

        private void tbl_simpan_Click(object sender, EventArgs e)
        {
            // Cek seluruh value yang ada pada textbox, jika kosong akan 
            // menampilkan message seperti dibawah
            if (pm.Text == "" || pg.Text == "" || tgl.Text == "" || masuk.Text == "" || keluar.Text == "" || metode.Text == "")
            {
                MessageBox.Show("Harap isi dulu!", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // Jika telah terisi value kita dapat memasukkannya ke dalam sistem class Catatan 
                // kemudian diteruskan ke database dengan menggunakan query insert pada class tersebut
                Catatan ctt = new Catatan();
                catatan.Pemasukan = pm.Text;
                catatan.Pengeluaran = pg.Text;
                catatan.Tanggal = tgl.Text;
                catatan.Jumlah_barang_masuk = masuk.Text;
                catatan.Jumlah_barang_keluar = keluar.Text;
                catatan.Metode_pembayaran = metode.Text;

                ctt.Insert(catatan);
                pm.Text = "";
                pg.Text = "";
                tgl.Text = "";
                masuk.Text = "";
                keluar.Text = "";
                metode.SelectedIndex = -1;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // List metode pembayaran
            metode.Items.Add("Cash");
            metode.Items.Add("Debit");
            timer1.Start();
        }

        private void tbl_dashboard3_Click(object sender, EventArgs e)
        {
            // Masuk beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_stk3_Click(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt3_Click(object sender, EventArgs e)
        {
            // Masuk pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr3_Click(object sender, EventArgs e)
        {
            // Masuk laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_prf3_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }
    }
}
