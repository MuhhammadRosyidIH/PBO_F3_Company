﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPBO.fiturPencatatan.modelPencatatan
{
    class modelCatatan
    {
        string pemasukan, pengeluaran, tanggal, jumlah_barang_masuk, jumlah_barang_keluar, metode_pembayaran;

        public modelCatatan() { }

        public modelCatatan(string pemasukan, string pengeluaran, string tanggal, string jumlah_barang_masuk, string jumlah_barang_keluar, string metode_pembayaran)
        {
            this.Pemasukan = pemasukan;
            this.Pengeluaran = pengeluaran;
            this.Tanggal = tanggal;
            this.Jumlah_barang_masuk = jumlah_barang_masuk;
            this.Jumlah_barang_keluar = jumlah_barang_keluar;
            this.Metode_pembayaran = metode_pembayaran;
        }

        public string Pemasukan { get => pemasukan; set => pemasukan = value; }
        public string Pengeluaran { get => pengeluaran; set => pengeluaran = value; }
        public string Tanggal { get => tanggal; set => tanggal = value; }
        public string Jumlah_barang_masuk { get => jumlah_barang_masuk; set => jumlah_barang_masuk = value; }
        public string Jumlah_barang_keluar { get => jumlah_barang_keluar; set => jumlah_barang_keluar = value; }
        public string Metode_pembayaran { get => metode_pembayaran; set => metode_pembayaran = value; }
    }
}
