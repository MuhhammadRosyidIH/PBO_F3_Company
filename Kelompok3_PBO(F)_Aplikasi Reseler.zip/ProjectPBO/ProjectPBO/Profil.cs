﻿using ProjectPBO.fiturPencatatan.viewPencatatan;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBO
{
    public partial class Profil : Form
    {
        koneksi Koneksi = new koneksi();
        public void Tampil_profil()
        {
            // Query database
            dataGridView1.DataSource = Koneksi.ShowData("SELECT * FROM akun");
            //Mengubah nama kolom
            dataGridView1.Columns[0].HeaderText = "NO";
            dataGridView1.Columns[1].HeaderText = "NAMA";
            dataGridView1.Columns[2].HeaderText = "EMAIL";
            dataGridView1.Columns[3].HeaderText = "PASSWORD";
            dataGridView1.Columns[4].HeaderText = "NO HP";
            dataGridView1.Columns[5].HeaderText = "DOMISILI";
        }
        public Profil()
        {
            InitializeComponent();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            // Kembali ke login
            Login login = new Login();
            login.Show();
            this.Hide();
       }

        private void tbl_dashboard5_Click(object sender, EventArgs e)
        {
            // Masuk beranda
            Beranda beranda = new Beranda();
            beranda.Show();
            this.Hide();
        }

        private void tbl_stok5_Click(object sender, EventArgs e)
        {
            // Masuk stok barang
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void tbl_ctt5_Click(object sender, EventArgs e)
        {
            // Masuk pencatatan
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void tbl_lpr5_Click(object sender, EventArgs e)
        {
            // Masuk laporan
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void tbl_prf5_Click(object sender, EventArgs e)
        {
            // Masuk profil
            Profil profil = new Profil();
            profil.Show();
            this.Hide();
        }

        private void Profil_Load(object sender, EventArgs e)
        {
            //Tampil data akun
            Tampil_profil();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            jam.Text = DateTime.Now.ToLongTimeString();
            tanggalHariIni.Text = DateTime.Now.ToLongDateString();
        }
    }
}
